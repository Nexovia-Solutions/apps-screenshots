import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart'; // Import connectivity_plus
import 'dart:async'; // Import for StreamSubscription
import 'package:url_launcher/url_launcher.dart'; // Import url_launcher for downloads

import '../../utils/network_manager.dart'; // Assuming this path is correct
import '../../utils/api_clients.dart'; // Assuming ApiClients is located here

class HomeScreen extends StatefulWidget {
  final String url;
  final bool fetchWithDio;

  const HomeScreen({required this.url, this.fetchWithDio = false, super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late WebViewController _webViewController;
  bool _isLoading = true;
  String? _errorLoadingContent;
  double _progress = 0;
  bool _isFallbackAttempted = false; // Flag to track fallback attempt
  String _currentUrl = ''; // To keep track of the URL currently being loaded
  bool _isMainPageSuccessfullyLoaded = false; // New flag to track main page load success

  // Connectivity related variables
  late StreamSubscription<List<ConnectivityResult>> _connectivitySubscription;
  bool _isConnected = true; // Assume connected initially

  final NetworkManager _networkManager = NetworkManager();

  @override
  void initState() {
    super.initState();
    _currentUrl = widget.url; // Initialize with the provided URL
    _initializeConnectivity(); // Initialize connectivity check
    _initializeWebViewController();
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel(); // Cancel subscription to prevent memory leaks
    super.dispose();
  }

  Future<void> _initializeConnectivity() async {
    // Initial check
    final connectivityResult = await (Connectivity().checkConnectivity());
    _updateConnectionStatus(connectivityResult);

    // Listen for changes
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen(_updateConnectionStatus);
  }

  void _updateConnectionStatus(List<ConnectivityResult> results) {
    bool connected = results.contains(ConnectivityResult.mobile) ||
        results.contains(ConnectivityResult.wifi) ||
        results.contains(ConnectivityResult.ethernet) ||
        results.contains(ConnectivityResult.vpn); // Consider VPN as connected

    if (_isConnected != connected) {
      setState(() {
        _isConnected = connected;
        if (!connected) {
          _errorLoadingContent = 'No internet connection. Please check your network settings.';
          _isLoading = false; // Stop loading indicator
        } else {
          // If connection is restored, try to load the page again
          _errorLoadingContent = null;
          _isFallbackAttempted = false; // Reset fallback on connection restore
          _currentUrl = widget.url; // Try original URL again
          _initializeWebViewController(); // Re-initialize to load content
        }
      });
    }
  }

  void _initializeWebViewController() {
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading progress
            setState(() {
              _progress = progress / 100;
              _isLoading = progress < 100;
            });
            debugPrint('WebView Progress: $progress%');
          },
          onPageStarted: (String url) {
            debugPrint('WebView Load Started: $url');
            setState(() {
              _isLoading = true;
              _errorLoadingContent = null;
              _progress = 0; // Reset progress on new page start
              _currentUrl = url; // Update current URL
              _isMainPageSuccessfullyLoaded = false; // Reset success flag
            });
          },
          onPageFinished: (String url) {
            debugPrint('WebView Load Stopped: $url');
            setState(() {
              _isLoading = false;
              _progress = 1; // Ensure progress is 100% when finished
              _isMainPageSuccessfullyLoaded = true; // Mark main page as loaded successfully
              _errorLoadingContent = null; // Clear any pending error if page finished
            });
          },
          onWebResourceError: (WebResourceError error) {
            String errorDetails = '';
            // Map common error types to user-friendly messages
            if (error.errorCode == -2 || error.description.contains('net::ERR_INTERNET_DISCONNECTED')) {
              errorDetails = 'No internet connection or host unreachable.';
              _errorLoadingContent = 'No internet connection. Please check your network settings.'; // Specific message
            } else if (error.errorCode == -8 || error.description.contains('net::ERR_CONNECTION_TIMED_OUT')) {
              errorDetails = 'Connection timed out.';
            } else if (error.errorCode == -6 || error.description.contains('net::ERR_FILE_NOT_FOUND')) {
              errorDetails = 'Resource not found.';
            } else if (error.errorCode == -10 || error.description.contains('net::ERR_UNSAFE_PORT')) {
              errorDetails = 'Unsafe resource blocked.';
            } else {
              errorDetails = '${error.description} (Code: ${error.errorCode})';
            }

            final String errorMessage =
                'WebView Error: $errorDetails on ${error.url ?? 'unknown URL'}';
            debugPrint(errorMessage);

            // Only trigger fallback or error display if the main page hasn't loaded successfully yet
            // and it's not a sub-resource error after the main page has loaded.
            if (!_isMainPageSuccessfullyLoaded) {
              if (!_isFallbackAttempted && _isConnected) { // Only fallback if connected
                debugPrint('Attempting to load fallback URL: ${ApiClients.baseUrl} due to main page error');
                setState(() {
                  _isFallbackAttempted = true;
                  _errorLoadingContent = null; // Clear error to try fallback
                  _isLoading = true;
                  _progress = 0;
                });
                _webViewController.loadRequest(Uri.parse(ApiClients.baseUrl));
              } else if (!_isConnected) {
                // If not connected, the _updateConnectionStatus already set the error
                debugPrint('Not connected, showing no internet screen.');
              } else {
                // If fallback has already been attempted and still failed, show the error
                setState(() {
                  _errorLoadingContent =
                  'Error loading content: $errorDetails\n Please try again.';
                  _isLoading = false;
                });
              }
            } else {
              // If main page has loaded successfully, just log sub-resource errors
              debugPrint('Sub-resource error after main page loaded: $errorMessage');
            }
          },
          onNavigationRequest: (NavigationRequest request) {
            // Block YouTube navigation as per original logic
            if (request.url.startsWith('https://www.youtube.com/')) {
              debugPrint('Blocked navigation to: ${request.url}');
              return NavigationDecision.prevent;
            }

            // Handle downloads: If the URL is likely a file download, launch it externally
            // You might need to refine this logic based on common download patterns
            // For example, checking file extensions like .pdf, .zip, .mp4, etc.
            if (request.url.endsWith('.pdf') ||
                request.url.endsWith('.zip') ||
                request.url.endsWith('.docx') ||
                request.url.endsWith('.xlsx') ||
                request.url.endsWith('.mp4') || // Added .mp4 based on your previous logs
                request.url.endsWith('.jpg') ||
                request.url.endsWith('.png') ||
                request.url.endsWith('.gif')) {
              debugPrint('Download detected: ${request.url}');
              _launchURL(request.url);
              return NavigationDecision.prevent; // Prevent WebView from loading it
            }

            return NavigationDecision.navigate;
          },
        ),
      );

    // Clear cache before loading content
    _webViewController.clearCache();
    _webViewController.clearLocalStorage();

    // Only load content if connected
    if (_isConnected) {
      if (widget.fetchWithDio) {
        _fetchContentAndLoad();
      } else {
        _webViewController.loadRequest(Uri.parse(_currentUrl)); // Load the initial or fallback URL
      }
    } else {
      // If not connected initially, set error message
      setState(() {
        _errorLoadingContent = 'No internet connection. Please check your network settings.';
        _isLoading = false;
      });
    }
  }

  // Helper function to launch URLs
  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $url');
      // Optionally show an error message to the user
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open download link: $url')),
      );
    }
  }

  Future<void> _fetchContentAndLoad() async {
    setState(() {
      _isLoading = true;
      _errorLoadingContent = null;
      _progress = 0;
      _isMainPageSuccessfullyLoaded = false; // Reset success flag for new fetch
    });

    // Only attempt to fetch if connected
    if (!_isConnected) {
      setState(() {
        _errorLoadingContent = 'No internet connection. Please check your network settings.';
        _isLoading = false;
      });
      return; // Exit if not connected
    }

    try {
      final response = await _networkManager.get<String>(
        _currentUrl, // Use currentUrl for Dio fetch
        options: Options(responseType: ResponseType.plain),
      );

      if (response.statusCode == 200 && response.data != null) {
        await _webViewController.loadHtmlString(
          response.data!,
          // Convert Uri to String for compatibility with older webview_flutter versions
          baseUrl: Uri.parse(_currentUrl).toString(),
        );
        // If HTML string loads successfully, mark main page as loaded.
        setState(() {
          _isMainPageSuccessfullyLoaded = true;
        });
      } else {
        // If initial load fails, attempt fallback
        if (!_isFallbackAttempted && _isConnected) { // Only fallback if connected
          debugPrint('Dio fetch failed, attempting fallback to ${ApiClients.baseUrl}');
          setState(() {
            _isFallbackAttempted = true;
            _errorLoadingContent = null; // Clear error to try fallback
            _currentUrl = ApiClients.baseUrl; // Set current URL to fallback
            _isLoading = true;
            _progress = 0;
          });
          await _webViewController.loadRequest(Uri.parse(_currentUrl));
        } else if (!_isConnected) {
          // If not connected, the _updateConnectionStatus already set the error
          debugPrint('Not connected, showing no internet screen.');
        } else {
          setState(() {
            _errorLoadingContent =
            'Failed to load content (Status: ${response.statusCode})';
          });
        }
      }
    } on DioException catch (e) {
      String userMessage = 'Network Error: ';
      if (e.type == DioExceptionType.connectionError) {
        userMessage += 'Please check your internet connection.';
        _errorLoadingContent = 'No internet connection. Please check your network settings.'; // Specific message
      } else if (e.type == DioExceptionType.badResponse) {
        userMessage += 'Server responded with error: ${e.response?.statusCode}';
      } else {
        userMessage += e.message ?? 'An unknown error occurred.';
      }

      // Attempt fallback if not already attempted and Dio error occurred
      if (!_isFallbackAttempted && _isConnected) { // Only fallback if connected
        debugPrint('Dio error, attempting fallback to ${ApiClients.baseUrl}');
        setState(() {
          _isFallbackAttempted = true;
          _errorLoadingContent = null; // Clear error to try fallback
          _currentUrl = ApiClients.baseUrl; // Set current URL to fallback
          _isLoading = true;
          _progress = 0;
        });
        await _webViewController.loadRequest(Uri.parse(_currentUrl));
      } else if (!_isConnected) {
        // If not connected, the _updateConnectionStatus already set the error
        debugPrint('Not connected, showing no internet screen.');
      } else {
        // If fallback has already been attempted and still failed, show the error
        setState(() {
          _errorLoadingContent = userMessage;
        });
        debugPrint('Dio Error: ${e.message}');
        if (e.response != null) {
          debugPrint('Dio Error Response: ${e.response?.data}');
        }
      }
    } finally {
      setState(() {
        _isLoading = false;
        _progress = 1; // Ensure progress is 100% after loading attempt
      });
    }
  }

  Future<void> _onRefresh() async {
    // When refreshing, reset fallback attempt and try the original URL again
    setState(() {
      _isFallbackAttempted = false;
      _isMainPageSuccessfullyLoaded = false; // Reset success flag on refresh
      _currentUrl = widget.url; // Reset to original URL on refresh
      _errorLoadingContent = null; // Clear error message on refresh
      _isLoading = true;
    });

    // Re-check connectivity and then load
    final connectivityResult = await (Connectivity().checkConnectivity());
    _updateConnectionStatus(connectivityResult);

    if (_isConnected) {
      if (widget.fetchWithDio) {
        await _fetchContentAndLoad();
      } else {
        await _webViewController.loadRequest(Uri.parse(_currentUrl));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // Display no internet screen if not connected
            if (!_isConnected)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.signal_wifi_off, // No internet icon
                        color: Colors.grey,
                        size: 60,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'No internet connection',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _errorLoadingContent ?? 'Please check your network settings and try again.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _onRefresh, // Use refresh to re-attempt connection
                        child: const Text('Retry Connection'),
                      ),
                    ],
                  ),
                ),
              )
            else if (_errorLoadingContent != null) // Show specific error if connected but page failed
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        color: Colors.red,
                        size: 60,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _errorLoadingContent!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.red,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          // On retry, reset fallback attempt and try the original URL again
                          setState(() {
                            _isFallbackAttempted = false;
                            _isMainPageSuccessfullyLoaded = false; // Reset success flag on retry
                            _currentUrl = widget.url; // Reset to original URL on retry
                          });
                          if (widget.fetchWithDio) {
                            _fetchContentAndLoad();
                          } else {
                            _webViewController.loadRequest(Uri.parse(_currentUrl));
                          }
                        },
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                ),
              )
            else // Show WebView if connected and no specific error
              RefreshIndicator( // Use RefreshIndicator for pull-to-refresh
                onRefresh: _onRefresh,
                child: WebViewWidget(
                  controller: _webViewController,
                ),
              ),
            if (_isLoading && _progress < 1.0 && _isConnected) // Show progress only if loading, not 100%, and connected
              LinearProgressIndicator(
                value: _progress,
                backgroundColor: Colors.grey[200],
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
              ),
            if (_isLoading && _progress == 0 && _isConnected) // Show circular indicator only if loading, 0 progress, and connected
              const Center(child: CircularProgressIndicator()),
          ],
        ),
      ),
    );
  }
}
