import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../utils/api_clients.dart';
import '../screens/home/home_screen.dart';
import '../screens/splash/splash_screen.dart';

final GoRouter goRouter = GoRouter(
  initialLocation: '/splash', // Start with splash screen
  routes: <RouteBase>[
    // Splash screen route
    GoRoute(
      path: '/splash',
      builder: (BuildContext context, GoRouterState state) {
        return const SplashScreen();
      },
    ),
    // Home screen route
    GoRoute(
      path: '/home',
      builder: (BuildContext context, GoRouterState state) {
        return HomeScreen(url: ApiClients.baseUrl);
      },
    ),
  ],
);
