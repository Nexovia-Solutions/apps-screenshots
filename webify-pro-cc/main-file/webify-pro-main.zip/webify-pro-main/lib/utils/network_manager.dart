// lib/network/network_manager.dart
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class NetworkManager {
  late Dio _dio;

  // Private constructor for Singleton pattern
  NetworkManager._internal() {
    _dio = Dio();
    // You can add global configurations here, e.g., base URL, headers, timeouts
    _dio.options.connectTimeout = const Duration(seconds: 10); // 10 seconds
    _dio.options.receiveTimeout = const Duration(seconds: 10); // 10 seconds
    // _dio.options.baseUrl = 'https://api.example.com'; // Example base URL

    // Add interceptors for logging, error handling, authentication, etc.
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          // Do something before request is sent
          debugPrint('REQUEST[${options.method}] => PATH: ${options.path}');
          return handler.next(options); //continue
        },
        onResponse: (response, handler) {
          // Do something with response data
          debugPrint('RESPONSE[${response.statusCode}] => PATH: ${response.requestOptions.path}');
          return handler.next(response); // continue
        },
        onError: (DioError e, handler) {
          // Do something with response error
          debugPrint('ERROR[${e.response?.statusCode}] => PATH: ${e.requestOptions.path}');
          return handler.next(e); //continue
        },
      ),
    );
  }

  // Singleton instance
  static final NetworkManager _instance = NetworkManager._internal();

  // Factory constructor to return the singleton instance
  factory NetworkManager() {
    return _instance;
  }

  // Generic GET request method
  Future<Response<T>> get<T>(
      String path, {
        Map<String, dynamic>? queryParameters,
        Options? options,
        CancelToken? cancelToken,
        ProgressCallback? onReceiveProgress,
      }) async {
    try {
      final response = await _dio.get<T>(
        path,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
        onReceiveProgress: onReceiveProgress,
      );
      return response;
    } on DioError {
      rethrow; // Re-throw the DioError to be handled by the caller
    }
  }

// You can add other HTTP methods (post, put, delete, etc.) here
// Future<Response<T>> post<T>(...) { ... }
}