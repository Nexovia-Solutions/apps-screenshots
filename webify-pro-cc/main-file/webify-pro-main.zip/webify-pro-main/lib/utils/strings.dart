class Strings {
  static String appName = "write your app name here";
}
