package com.nexoviasolutions.webify_pro_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
